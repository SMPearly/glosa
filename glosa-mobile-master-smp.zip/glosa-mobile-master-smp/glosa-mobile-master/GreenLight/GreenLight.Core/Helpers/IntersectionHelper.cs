﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreenLight.Core.Helpers
{
    public class IntersectionHelper : WaypointHelper
    {

    }
}
